AUREX 1.2.1 — Apple Silicon macOS 14.2+

Open Aurex.app. Hover to expand; leave to collapse. The compact island uses a dark,
rounded shape with artwork on the left, animated bars and a colourful light.
Expanded controls use native AppKit Liquid Glass on macOS 26/27.

CHROME
The included companion provides real title, thumbnail, playback state and play/pause.
Run Connect Chrome.command, then load ChromeCompanion at chrome://extensions using
Load unpacked. This grants the extension access to media on websites; all playback
metadata stays on your Mac. Refresh existing music tabs once after installation.
Chrome companion back/forward controls seek 10 seconds. Apple Music controls skip tracks.
Without the companion, system media keys require macOS Accessibility permission.
The app reports missing permission in the music panel rather than disabling controls.

SHELF
Drag files, folders, apps or text onto the island. Hover again and drag any shelf
icon into Finder, the desktop, an editor or another compatible app. Native AppKit
pasteboard and drag sessions are used. The shelf keeps references to originals;
text snippets become local .txt files. Right-click to remove a shelf reference.

UPDATES
Sparkle checks the signed release feed every hour and offers Install Update / Later.
https://github.com/jezaedition/aurex-releases
The 1.2 version must be installed once on older machines; earlier builds had no
updater. Only published releases produce update prompts, not local source edits.
ReleaseTools contains packaging instructions. The private publisher signing key
is kept separately in the external disk's hidden .publisher folder. Never distribute it.

Settings controls size/position and login launch. Keep the external disk mounted.
Alarms require the Mac awake and Aurex running. Focus is an in-app timer.
Camera turns off when the preview closes. macOS controls camera/automation permissions.

This is an ad-hoc signed development build, not Apple-notarized distribution.
