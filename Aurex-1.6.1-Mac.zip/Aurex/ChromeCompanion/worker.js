'use strict';
const MAX_IMAGE=2_000_000;
const ACTIONS=new Set(['playpause','previous track','next track']);
let port,lastState,lastTab,lastFrame,lastArtworkURL,artwork,seenCommand,reconnectTimer;
function connect(){
 if(port)return;
 try{
  const connection=chrome.runtime.connectNative('studio.aurex.media');port=connection;
  connection.onMessage.addListener(cmd=>{
   if(!ACTIONS.has(cmd.action)||typeof cmd.id!=='string'||cmd.id===seenCommand||lastTab==null)return;
   seenCommand=cmd.id;
   chrome.tabs.sendMessage(lastTab,{type:'command',action:cmd.action},{frameId:lastFrame}).catch(()=>{});
  });
  connection.onDisconnect.addListener(()=>{void chrome.runtime.lastError;if(port===connection)port=null;clearTimeout(reconnectTimer);reconnectTimer=setTimeout(connect,3000)});
 }catch{port=null}
}
function artworkURL(raw,page){
 try{
  if(typeof raw!=='string'||raw.length>4096)return null;
  const url=new URL(raw),source=new URL(page);
  if(url.protocol!=='https:'||url.username||url.password||url.port&&url.port!=='443')return null;
  const h=url.hostname.toLowerCase();
  if(!h.includes('.')||h.includes(':')||/^\d+(\.\d+){3}$/.test(h)||h.endsWith('.local')||h.endsWith('.localhost')||h.endsWith('.internal'))return null;
  const cdn=['ytimg.com','googleusercontent.com','scdn.co','sndcdn.com'];
  if(url.origin!==source.origin&&!cdn.some(d=>h===d||h.endsWith('.'+d)))return null;
  return url.href;
 }catch{return null}
}
async function fetchArtwork(url){
 const response=await fetch(url,{credentials:'omit',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(6000)});
 const mime=response.headers.get('content-type')?.split(';')[0].toLowerCase();
 if(!response.ok||!['image/jpeg','image/png','image/webp','image/gif','image/heic','image/avif'].includes(mime))return null;
 const declared=Number(response.headers.get('content-length'));
 if(declared>MAX_IMAGE)return null;
 const reader=response.body?.getReader();if(!reader)return null;
 const chunks=[];let length=0;
 while(true){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>MAX_IMAGE){await reader.cancel();return null}chunks.push(value)}
 const bytes=new Uint8Array(length);let offset=0;for(const part of chunks){bytes.set(part,offset);offset+=part.length}
 let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary);
}
connect();
chrome.runtime.onMessage.addListener((msg,sender)=>{
 if(sender.id!==chrome.runtime.id||!sender.tab||msg.type!=='state'||typeof msg.playing!=='boolean'||typeof msg.title!=='string'||typeof msg.artist!=='string'||!/^https?:\/\//.test(sender.url||''))return;
 if(lastState?.playing&&!msg.playing&&(sender.tab.id!==lastTab||sender.frameId!==lastFrame))return;
 lastTab=sender.tab.id;lastFrame=sender.frameId;
 const candidate=artworkURL(msg.artworkURL,sender.url);
 if(candidate!==lastArtworkURL){lastArtworkURL=candidate;artwork=undefined;if(candidate){fetchArtwork(candidate).then(result=>{if(lastArtworkURL===candidate)artwork=result||undefined}).catch(()=>{})}}
 lastState={title:msg.title.slice(0,512),artist:msg.artist.slice(0,256),playing:msg.playing,position:Number.isFinite(msg.position)&&msg.position>=0?msg.position:0,duration:Number.isFinite(msg.duration)&&msg.duration>0?msg.duration:0,artwork,updated:Date.now()/1000};
 if(!port)connect();try{port?.postMessage(lastState)}catch{port=null}
});
