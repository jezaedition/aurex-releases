#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
host_dir="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
mkdir -p "$host_dir"
host_file="$host_dir/studio.aurex.media.json"
if [[ -L "$host_file" ]]; then
  print -u2 'Cannot replace a linked Chrome configuration.'
  exit 1
fi
stage_file=$(mktemp "$host_dir/.aurex.XXXXXX")
trap 'rm -f "$stage_file"' EXIT
/usr/bin/plutil -create xml1 "$stage_file"
/usr/bin/plutil -insert name -string studio.aurex.media "$stage_file"
/usr/bin/plutil -insert description -string 'Aurex local media bridge' "$stage_file"
/usr/bin/plutil -insert path -string "$PWD/Aurex.app/Contents/MacOS/Aurex" "$stage_file"
/usr/bin/plutil -insert type -string stdio "$stage_file"
/usr/bin/plutil -insert allowed_origins -json '["chrome-extension://ljhlccngoadjmpknnnmhnnlaieibehnl/"]' "$stage_file"
/usr/bin/plutil -convert json "$stage_file"
chmod 600 "$stage_file"
mv -f "$stage_file" "$host_file"
open -a 'Google Chrome' chrome://extensions/
open ChromeCompanion
print 'Chrome: turn on Developer mode, choose Load unpacked and select this ChromeCompanion folder. Refresh the music tab.'
