#!/bin/zsh
set -e
cd "${0:A:h}"
/usr/bin/python3 - "$PWD/Aurex.app/Contents/MacOS/Aurex" "$PWD/ChromeCompanion/extension-id.txt" <<'PY'
import json,sys,pathlib
folder=pathlib.Path.home()/'Library/Application Support/Google/Chrome/NativeMessagingHosts'
folder.mkdir(parents=True,exist_ok=True)
d={'name':'studio.aurex.media','description':'Aurex local media bridge','path':sys.argv[1],'type':'stdio','allowed_origins':['chrome-extension://'+pathlib.Path(sys.argv[2]).read_text().strip()+'/']}
(folder/'studio.aurex.media.json').write_text(json.dumps(d))
PY
open -a 'Google Chrome' chrome://extensions/
open ChromeCompanion
print 'Chrome: enable Developer mode, choose Load unpacked, and select the ChromeCompanion folder. Reload your music tab once.'
