(()=>{
 let lastMedia;
 const media=()=>{const all=[...document.querySelectorAll('video,audio')];return all.find(m=>!m.paused&&!m.ended)||lastMedia||all[0]};
 async function report(){const m=media();if(!m)return;lastMedia=m;const meta=navigator.mediaSession?.metadata;const artwork=meta?.artwork?.slice(-1)[0]?.src||document.querySelector('meta[property="og:image"]')?.content;chrome.runtime.sendMessage({type:'state',title:meta?.title||document.title,artist:meta?.artist||location.hostname,playing:!m.paused&&!m.ended,artworkURL:artwork}).catch(()=>{})}
 for(const event of ['play','pause','ended','loadedmetadata'])document.addEventListener(event,report,true);
 setInterval(report,900);
 chrome.runtime.onMessage.addListener(msg=>{if(msg.type!=='command')return;const m=media();if(!m)return;if(msg.action==='playpause'){if(m.paused)m.play().catch(()=>{});else m.pause()}else if(msg.action==='next track')m.currentTime=Math.min(m.duration||Infinity,m.currentTime+10);else if(msg.action==='previous track')m.currentTime=Math.max(0,m.currentTime-10);report()});
})();
